import XCTest
import SQLite

class StatementTests : XCTestCase {
}
