# SQLiteApp
This is the Xcode project that I work on in the article "Using SQLite in iOS apps".
